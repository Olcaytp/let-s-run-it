package app.lovable.constructionmanagement;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
